/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fitnessmanagersystem;

import static com.oracle.util.Checksums.update;
import static fitnessmanagersystem.AddClient.jButton1wevwevwe;
import static fitnessmanagersystem.AddClient.jButton222222222;
import static fitnessmanagersystem.AddClient.jButton2camera;
import static fitnessmanagersystem.AddClient.jLabel10sadvasd;

import static fitnessmanagersystem.AddClient.jTextField_IdClient1;

import static fitnessmanagersystem.GUI.Panel11;
import static fitnessmanagersystem.OpenWindowClient.jComboBox_City11;
import static fitnessmanagersystem.OpenWindowClient.jComboBox_Sex11;
import static fitnessmanagersystem.OpenWindowClient.jLabel1000;
import static fitnessmanagersystem.OpenWindowClient.jTextField_Age;
import static fitnessmanagersystem.OpenWindowClient.jTextField_Emailaa;
import static fitnessmanagersystem.OpenWindowClient.jTextField_FirstName111;
import static fitnessmanagersystem.OpenWindowClient.jTextField_IdClient11;
import static fitnessmanagersystem.OpenWindowClient.jTextField_LastName;
import static fitnessmanagersystem.OpenWindowClient.jTextField_Street111;
import static fitnessmanagersystem.OpenWindowClient.jTextField_Telephone11;
import static fitnessmanagersystem.SendEmail1.jButton1_addFile1;
import static fitnessmanagersystem.SendEmail1.jButton2_addFile2;
import static fitnessmanagersystem.SendEmail1.jButton3_addFile3;
import static fitnessmanagersystem.SendEmail1.jButton4_addFile4;
import static fitnessmanagersystem.SendEmail1.jTextField1_addFile1;
import static fitnessmanagersystem.SendEmail1.jTextField2__addFile2;
import static fitnessmanagersystem.SendEmail1.jTextField3__addFile3;
import static fitnessmanagersystem.SendEmail1.jTextField4__addFile4;
import static fitnessmanagersystem.SendEmail1.txtto1;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Image;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import org.jdesktop.swingx.prompt.PromptSupport;

/**
 *
 * @author DISHLIEV
 */

public final class SearchClient extends javax.swing.JPanel {

    /**
     * Creates new form SearchClient
     */
    public SearchClient() {
        initComponents();
        findUsers();
    }
     public static String id;
    public static String firstName;
    public static String lastName;
    public static String dateOfBirdth;
    public static String sex;
   public static String telephone;
   public static String city;
    public static String street;
       public static String email;
       

   public Connection getConnection()
   {
       Connection con;
    
       try {
           con = DriverManager.getConnection("jdbc:mysql://localhost/fitness-manager-system?characterEncoding=utf8", "root","");
         
           return con;
       } catch (Exception e) {
           return null;
       }
   }
        public ArrayList<Clients> ListUsers(String valToSearch){
            ArrayList<Clients> usersList = new ArrayList<>();
          
            Statement st;
            ResultSet rs;
            
            try{
                   Connection con = getConnection();
             st= con.createStatement();
            String searchQuery = "SELECT * FROM  `clients` WHERE CONCAT(`id`, `firstName`, `lastName`, `dateOfBirdth` ) LIKE'%"+valToSearch+"%'";
             rs = st.executeQuery(searchQuery);
             Clients user;
             
             while(rs.next()){
             
                 user = new Clients(rs.getInt("id"),rs.getString("firstName"),rs.getString("lastName"),rs.getString("dateOfBirdth"),rs.getString("sex"),rs.getInt("telephone"),rs.getString("city"),rs.getString("street"),rs.getString("email"),rs.getString("admin"), rs.getString("admin2"));
                   usersList.add(user);
             }
            }catch(Exception ex){
                System.out.println(ex.getMessage());
            }
   return usersList;
   
        }
        
     public void findUsers() {
        ArrayList<Clients> users = ListUsers(jText_SearchClient.getText());

        DefaultTableModel model = new DefaultTableModel();
      
        model.setColumnIdentifiers(new Object[]{"ID номер", "име", "фамилия", "дата на раждане", "пол", "тел.", "град", "улица", "емайл", "администратор", "последна промяна"});
        Object[] row = new Object[11];

        for (Clients user : users) {
            row[0] = user.getID();
            row[1] = user.getFirstName();
            row[2] = user.getLastName();
            row[3] = user.getDateOfBirdth();
            row[4] = user.getSex();
            row[5] = user.getTelephone();
            row[6] = user.getCity();
            row[7] = user.getStreet();
            row[8] = user.getEmail();
            row[9] = user.getAdmin();
            row[10] = user.getAdmin2();
            model.addRow(row);
        }
        jTable1_clients.setModel(model);

    }
     //  final JTable table = new JTable(model);
        public ArrayList<Clients> getUsersList()
   {
       ArrayList<Clients> usersList = new ArrayList<>();
       Connection connection = getConnection();
       
       String query = "SELECT * FROM  `clients`";
       // String searchQuery = "SELECT * FROM  `users`CONCAT(`id`, `fname`, `lname`, `age`, `sex`, `telephone`, `city`, `street`, `dateOfIssue`, `expiryDate`, `typeCard`, `visits`) LIKE'%"+valToSearch+"%'";
       Statement st;
       ResultSet rs;
       
       try {
           st = connection.createStatement();
           rs = st.executeQuery(query);
          
           Clients Client;
         //  Card card;
           while(rs.next())
           {
               Client = new Clients(rs.getInt("id"),rs.getString("firstName"),rs.getString("lastName"),rs.getString("dateOfBirdth"),rs.getString("sex"),rs.getInt("telephone"),rs.getString("city"),rs.getString("street"),rs.getString("email"),rs.getString("admin"), rs.getString("admin2"));
               usersList.add(Client);
               //card = new Card(rs.getInt("nomer"));
           }
       } catch (Exception e) {
       }
       return usersList;
   }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jText_SearchClient = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1_clients = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jPanel1111111 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();

        jText_SearchClient.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jText_SearchClientKeyTyped(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\DISHLIEV\\Documents\\1\\FitnessManagerSystem\\icons\\search-icon.png")); // NOI18N

        jTable1_clients.setAutoCreateRowSorter(true);
        jTable1_clients.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1_clients.setRowHeight(30);
        jTable1_clients.setSelectionBackground(new java.awt.Color(255, 51, 51));
        jScrollPane1.setViewportView(jTable1_clients);

        jButton2.setIcon(new javax.swing.ImageIcon("C:\\Users\\DISHLIEV\\Documents\\1\\FitnessManagerSystem\\icons\\export.png")); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\DISHLIEV\\Documents\\1\\FitnessManagerSystem\\icons\\open.png")); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton5.setIcon(new javax.swing.ImageIcon("C:\\Users\\DISHLIEV\\Documents\\1\\FitnessManagerSystem\\icons\\email-send-icon-small.png")); // NOI18N
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1111111Layout = new javax.swing.GroupLayout(jPanel1111111);
        jPanel1111111.setLayout(jPanel1111111Layout);
        jPanel1111111Layout.setHorizontalGroup(
            jPanel1111111Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 249, Short.MAX_VALUE)
        );
        jPanel1111111Layout.setVerticalGroup(
            jPanel1111111Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        jButton6.setIcon(new javax.swing.ImageIcon("C:\\Users\\DISHLIEV\\Documents\\1\\FitnessManagerSystem\\icons\\Male-user-add-iconSMAL.png")); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setIcon(new javax.swing.ImageIcon("C:\\Users\\DISHLIEV\\Documents\\1\\FitnessManagerSystem\\icons\\delete.png")); // NOI18N
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jText_SearchClient, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(133, 133, 133)
                        .addComponent(jButton2)
                        .addGap(18, 18, 18)
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton7))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(338, 338, 338)
                        .addComponent(jPanel1111111, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(751, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton7))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton2)
                                    .addComponent(jButton3)
                                    .addComponent(jButton5)))
                            .addComponent(jLabel1)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(432, 432, 432)
                        .addComponent(jText_SearchClient, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1111111, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(50, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jText_SearchClientKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jText_SearchClientKeyTyped
         jText_SearchClient.getDocument().addDocumentListener(new DocumentListener() {

            @Override
            public void insertUpdate(DocumentEvent de) {
                findUsers();
            }

            @Override
            public void removeUpdate(DocumentEvent de) {
                findUsers();
            }

            @Override
            public void changedUpdate(DocumentEvent de) {
                findUsers();
            }

        });
    }//GEN-LAST:event_jText_SearchClientKeyTyped

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
     ExportPanel p1 = new ExportPanel();
    p1.setSize(949, 100);
                            p1.setLocation(0, 0);
                            
                            jPanel1111111.setLayout(new GridLayout(0,1));
                            jPanel1111111.removeAll();
                            jPanel1111111.add(p1,BorderLayout.PAGE_END);
                            jPanel1111111.revalidate();
                            jPanel1111111.repaint();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
 
        
        
        
        int row = jTable1_clients.getSelectedRow();

if(row == -1)
{
  JOptionPane.showMessageDialog(null,"Изберете клиент!");
}
else
{
         
        OpenWindowClient p1 = new OpenWindowClient();
        p1.setSize(1000, 500);
        p1.setLocation(0, 0);
        Panel11.removeAll();
        Panel11.add(p1,BorderLayout.AFTER_LAST_LINE);
        Panel11.revalidate();
        Panel11.repaint();
        TableModel model = jTable1_clients.getModel();
        int i = jTable1_clients.getSelectedRow();
        SearchClient.id = model.getValueAt(i,0).toString();
        SearchClient.firstName = model.getValueAt(i,1).toString();
        SearchClient.lastName = model.getValueAt(i,2).toString();
        SearchClient.dateOfBirdth = model.getValueAt(i,3).toString();
        SearchClient.sex = model.getValueAt(i,4).toString();
        SearchClient.telephone = model.getValueAt(i,5).toString();
        SearchClient.city = model.getValueAt(i,6).toString();
        SearchClient.street = model.getValueAt(i,7).toString();
        SearchClient.email = model.getValueAt(i,8).toString();
        jTextField_IdClient11.setText(id);
        jTextField_FirstName111.setText(firstName);
        jTextField_LastName.setText(lastName);
        jTextField_Age.setText(dateOfBirdth);
        jComboBox_Sex11.setSelectedItem(sex);
        jTextField_Telephone11.setText(telephone);
        jComboBox_City11.setSelectedItem(city);
        jTextField_Street111.setText(street);
        jTextField_Emailaa.setText(email);
        jTextField_IdClient11.setEditable(false);
        jTextField_FirstName111.setEditable(false);
        jTextField_LastName.setEditable(false);
        jTextField_Age.setEditable(false);
        jComboBox_Sex11.setEditable(false);
        jTextField_Telephone11.setEditable(false);
        jTextField_Emailaa.setEditable(false);
        jComboBox_City11.setEditable(false);
        jTextField_Street111.setEditable(false);
   
}
     try{
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/fitness-manager-system","root","");
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("select * from clientsimages where ID = '"+id+"'");
                if(rs.next()){
                    byte[] img = rs.getBytes("Image");


                    //Resize The ImageIcon
                    ImageIcon image = new ImageIcon(img);
                    Image im = image.getImage();
                    Image myImg = im.getScaledInstance(195,195,Image.SCALE_SMOOTH);
                    ImageIcon newImage = new ImageIcon(myImg);
                    jLabel1000.setIcon(newImage);
                }
                
                else{
                  //  JOptionPane.showMessageDialog(null, "Няма снимка!");
                }
            }catch(SQLException | HeadlessException ex){
            }
        
        
    
    
   
  
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        AddClient p1 = new AddClient();
        p1.setSize(1000, 500);
        p1.setLocation(0, 0);

        Panel11.removeAll();
        Panel11.add(p1,BorderLayout.AFTER_LAST_LINE);
        Panel11.revalidate();
        Panel11.repaint();
        jButton222222222.setEnabled(false);
        // взима от базата с клиенти най-голямото ID + 1
        try {
            Connection con;
            Statement st;
            ResultSet rs;

            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/fitness-manager-system?characterEncoding=utf8", "root", "");
            st = con.createStatement();
            rs = st.executeQuery("select max(id) from clients");

            int i = 100;

            while (rs.next()) {

                i = rs.getInt(1) + 1;
            }
            jTextField_IdClient1.setText("" + i);
            con.close();
            st.close();
            rs.close();
        } catch (ClassNotFoundException | SQLException e) {
        }
        
        jLabel10sadvasd.setEnabled(false);
        jButton1wevwevwe.setEnabled(false);
        jButton2camera.setEnabled(false);

        
        
    
        
        
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
   int row = jTable1_clients.getSelectedRow();

if(row == -1)
{
  JOptionPane.showMessageDialog(null,"Изберете клиент!");
}
else
{
        
        
        
        DeleteClient frame = new DeleteClient();
frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setVisible(true);
}
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
 int row = jTable1_clients.getSelectedRow();

if(row == -1)
{
  JOptionPane.showMessageDialog(null,"Изберете клиент!");
}
else
{
        
        SendEmail1 p1 = new SendEmail1();
    p1.setSize(1000, 500);
    p1.setLocation(0, 0);
    
    Panel11.setLayout(new GridLayout(0,1));
    Panel11.removeAll();
    Panel11.add(p1,BorderLayout.PAGE_END);
    Panel11.revalidate();
    Panel11.repaint();
          TableModel model = jTable1_clients.getModel();
        int i = jTable1_clients.getSelectedRow();
        
         SearchClient.email = model.getValueAt(i,8).toString();
       
               
       txtto1.setText(email);
}
  jTextField1_addFile1.setVisible(false);
        jTextField2__addFile2.setVisible(false);
        jTextField3__addFile3.setVisible(false);
        jTextField4__addFile4.setVisible(false);
        
        jButton1_addFile1.setVisible(false);
        jButton2_addFile2.setVisible(false);
        jButton3_addFile3.setVisible(false);
        jButton4_addFile4.setVisible(false);
    }//GEN-LAST:event_jButton5ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    public javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1111111;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable1_clients;
    private javax.swing.JTextField jText_SearchClient;
    // End of variables declaration//GEN-END:variables
}
