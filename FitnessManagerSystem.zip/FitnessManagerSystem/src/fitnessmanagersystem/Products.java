/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fitnessmanagersystem;

/**
 *
 * @author DISHLIEV
 */
public class Products {
   private final int id;
   private final String name;
   private final String brand;
   private final String category;
   private final String information;
  private final int pieces;
   private final double price;
   
    public Products(int ID, String Name, String Brand, String Category,String Information, int Pieces, double Price){
    
        this.id = ID;
        this.name= Name;
        this.brand = Brand;
        this.category = Category;
        this.information = Information;
        this.pieces = Pieces;
       this.price = Price;
           
    }


        public int getID(){
            return id;
       }
       public String getName(){
           return name;
       }
        public String getBrand(){
           return brand;
       }
             public String getCategory(){
           return category;
       }
         public String getInformation(){
           return information;
       }
          public int getPieces(){
           return pieces;
           }
           public double getPrice(){
           return price;
           }
    }
