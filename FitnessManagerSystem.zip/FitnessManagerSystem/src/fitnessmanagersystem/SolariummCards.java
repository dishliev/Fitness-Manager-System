/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fitnessmanagersystem;

/**
 *
 * @author DISHLIEV
 */
public class SolariummCards {
     private String type;
    private int minutes;
    private int periodDays;
    private double price;
     public SolariummCards( String Type, int Minutes, int PeriodDays, double Price){
    
      
        this.type= Type;
        this.minutes = Minutes;
        this.periodDays = PeriodDays;
        this.price = Price;
           
    }

      
        public String getType(){
            return type;
        }
        public int getMinutes(){
            return minutes;
        }
        public int getPeriodDays(){
            return periodDays;
        }
        public double getPrice(){
            return price;
        }
    }





