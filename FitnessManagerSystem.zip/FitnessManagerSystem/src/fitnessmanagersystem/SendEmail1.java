/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fitnessmanagersystem;

import static fitnessmanagersystem.GUI.Panel11;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import java.util.Scanner;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.JFileChooser;
import javax.swing.Timer;

/**
 *
 * @author DISHLIEV
 */
public class SendEmail1 extends javax.swing.JPanel {

    public static String selectedFile;
    public static String selectedFile1;
    public static String selectedFile2;
    public static String selectedFile3;

    public SendEmail1() {
        initComponents();

    }

    public static void sendEmailWithAttachments(String host, String port,
            final String userName, final String password, String toAddress,
            String subject, String message, String[] attachFiles)
            throws AddressException, MessagingException {

        Properties properties = new Properties();
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", port);
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.user", userName);
        properties.put("mail.password", password);

        Authenticator auth = new Authenticator() {
            @Override
            public PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(userName, password);
            }
        };
        Session session = Session.getInstance(properties, auth);

        Message msg = new MimeMessage(session);

        msg.setFrom(new InternetAddress(userName));
        InternetAddress[] toAddresses = {new InternetAddress(toAddress)};
        msg.setRecipients(Message.RecipientType.TO, toAddresses);
        msg.setSubject(subject);
        msg.setSentDate(new Date());

        MimeBodyPart messageBodyPart = new MimeBodyPart();
        messageBodyPart.setContent(message, "text/html");

        Multipart multipart = new MimeMultipart();
        multipart.addBodyPart(messageBodyPart);

        if (attachFiles != null && attachFiles.length > 0) {
            for (String filePath : attachFiles) {
                MimeBodyPart attachPart = new MimeBodyPart();

                try {
                    attachPart.attachFile(filePath);
                } catch (IOException ex) {

                }

                multipart.addBodyPart(attachPart);
            }
        }

        msg.setContent(multipart);

        Transport.send(msg);

    }

    private class MailAuthenticator extends javax.mail.Authenticator {

        private PasswordAuthentication authentication = null;
        private String username;
        private String password;

        public MailAuthenticator() {
           this.username = txtusername.getText();
           this.password = jPasswordField1passsss.getText();
           this.authentication = new PasswordAuthentication(username, password);
        }

        @Override
        protected PasswordAuthentication getPasswordAuthentication() {
            return authentication;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton3 = new javax.swing.JButton();
        jTextField1_hostName = new javax.swing.JTextField();
        txtto1 = new javax.swing.JTextField();
        lblInfo = new javax.swing.JLabel();
        txtusername = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtcontent = new javax.swing.JTextArea();
        jButton1sendEmail = new javax.swing.JButton();
        jButton1_addFile1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtPort = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtsubject = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTextField1_addFile1 = new javax.swing.JTextField();
        jTextField2__addFile2 = new javax.swing.JTextField();
        jButton2_addFile2 = new javax.swing.JButton();
        jButton3_addFile3 = new javax.swing.JButton();
        jTextField3__addFile3 = new javax.swing.JTextField();
        jCheckBox1ascdasvdas = new javax.swing.JCheckBox();
        jTextField4__addFile4 = new javax.swing.JTextField();
        jButton4_addFile4 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jPasswordField1passsss = new javax.swing.JPasswordField();

        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\DISHLIEV\\Documents\\1\\FitnessManagerSystem\\icons\\cancel.png")); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jTextField1_hostName.setText("smtp.gmail.com");

        txtto1.setText("kiril.dishliev1@abv.bg");

        lblInfo.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N

        txtusername.setText("siiskasardjova@gmail.com");

        txtcontent.setColumns(20);
        txtcontent.setRows(5);
        jScrollPane1.setViewportView(txtcontent);

        jButton1sendEmail.setText("изпрати");
        jButton1sendEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1sendEmailActionPerformed(evt);
            }
        });

        jButton1_addFile1.setIcon(new javax.swing.ImageIcon("C:\\Users\\DISHLIEV\\Documents\\1\\FitnessManagerSystem\\icons\\paperclip2_black3.png")); // NOI18N
        jButton1_addFile1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1_addFile1ActionPerformed(evt);
            }
        });

        jLabel1.setText("Порт:");

        jLabel2.setText("SMTP server:");

        jLabel3.setText("Email:");

        jLabel4.setText("Парола:");

        txtPort.setText("465");

        jLabel6.setText("ДО:");

        jLabel7.setText("Тема:");

        jButton2_addFile2.setIcon(new javax.swing.ImageIcon("C:\\Users\\DISHLIEV\\Documents\\1\\FitnessManagerSystem\\icons\\paperclip2_black3.png")); // NOI18N
        jButton2_addFile2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2_addFile2ActionPerformed(evt);
            }
        });

        jButton3_addFile3.setIcon(new javax.swing.ImageIcon("C:\\Users\\DISHLIEV\\Documents\\1\\FitnessManagerSystem\\icons\\paperclip2_black3.png")); // NOI18N
        jButton3_addFile3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3_addFile3ActionPerformed(evt);
            }
        });

        jCheckBox1ascdasvdas.setText("прикачи файлове");
        jCheckBox1ascdasvdas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jCheckBox1ascdasvdasMouseClicked(evt);
            }
        });
        jCheckBox1ascdasvdas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ascdasvdasActionPerformed(evt);
            }
        });

        jButton4_addFile4.setIcon(new javax.swing.ImageIcon("C:\\Users\\DISHLIEV\\Documents\\1\\FitnessManagerSystem\\icons\\paperclip2_black3.png")); // NOI18N
        jButton4_addFile4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4_addFile4ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N

        jPasswordField1passsss.setText("0879991836");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(lblInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 532, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1sendEmail)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                        .addComponent(jButton3)
                        .addGap(113, 113, 113))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(44, 44, 44)
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane1)
                                    .addComponent(txtsubject)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtusername, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addGap(18, 18, 18)
                                        .addComponent(jPasswordField1passsss, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addGap(18, 18, 18)
                                        .addComponent(jTextField1_hostName, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(10, 10, 10)
                                        .addComponent(txtto1, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(28, 28, 28)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel1)
                                                .addGap(18, 18, 18)
                                                .addComponent(txtPort, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(51, 51, 51)
                                                .addComponent(jCheckBox1ascdasvdas)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jTextField1_addFile1, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(0, 0, Short.MAX_VALUE)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(jTextField2__addFile2)
                                                    .addComponent(jTextField3__addFile3, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jTextField4__addFile4, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButton3_addFile3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton1_addFile1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton2_addFile2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton4_addFile4, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(38, 38, 38))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField1_hostName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(txtPort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)
                            .addComponent(jCheckBox1ascdasvdas))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtusername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(12, 12, 12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jPasswordField1passsss, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtto1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton1_addFile1)
                                .addGap(4, 4, 4)
                                .addComponent(jButton2_addFile2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton3_addFile3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton4_addFile4))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jTextField1_addFile1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField2__addFile2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(11, 11, 11)
                                .addComponent(jTextField3__addFile3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(11, 11, 11)
                                .addComponent(jTextField4__addFile4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtsubject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblInfo, javax.swing.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jButton1sendEmail)
                                .addComponent(jButton3))
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        HomePanel p1 = new HomePanel();
        p1.setSize(949, 100);
        p1.setLocation(0, 0);

        Panel11.setLayout(new GridLayout(0,1));
        Panel11.removeAll();
        Panel11.add(p1,BorderLayout.PAGE_END);
        Panel11.revalidate();
        Panel11.repaint();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1sendEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1sendEmailActionPerformed
/*
        jLabel5.setText("Моля изчакайте.");
        try{
           Thread.sleep(5*1000);
        
        }catch(Exception e){}
      //  jLabel1.setText("Моля изчакайте..");
      //  jLabel1.setText("Моля изчакайте...");
 //
        */
        
        if(jTextField1_addFile1.getText().length()>0 
                || jTextField3__addFile3.getText().length()>0 
                || jTextField2__addFile2.getText().length()>0)
        { 
try{
        

               String host = jTextField1_hostName.getText();//"smtp.gmail.com";
        String port = txtPort.getText();//"587";
        String mailFrom = txtusername.getText();//"siiskasardjova@gmail.com";
        String password = jPasswordField1passsss.getText();//"0879991836";
 
        // message info
        String mailTo = txtto1.getText();//"mx_k@abv.bg";
        String subject = txtsubject.getText();//"New email with attachments";
        String message = txtcontent.getText();//"I have some attachments for you.";
 
        // attachments
       
        if(jTextField1_addFile1.getText().length()>0){
        String[] attachFiles = new String[1];
        attachFiles[0] = selectedFile;
         try {
            sendEmailWithAttachments(host, port, mailFrom, password, mailTo,
                subject, message, attachFiles);
           lblInfo.setText("Вашият емайл е изпратен успешно."); 
            lblInfo.setForeground(Color.GREEN);
        } catch (Exception ex) {
         lblInfo.setText("Вашият емайл не е изпратен успешно."); 
            lblInfo.setForeground(Color.red);
        }
        }
        
        if(jTextField1_addFile1.getText().length()>0 
            && jTextField2__addFile2.getText().length()>0){
            
             @SuppressWarnings("MismatchedReadAndWriteOfArray")
             String[] attachFiles = new String[2];
        attachFiles[0] = selectedFile;
        attachFiles[1] = selectedFile1;       
        try {
            sendEmailWithAttachments(host, port, mailFrom, password, mailTo,
                subject, message, attachFiles);
         lblInfo.setText("Вашият емайл е изпратен успешно."); 
          lblInfo.setForeground(Color.GREEN);
        } catch (Exception ex) {
          lblInfo.setText("Вашият емайл не е изпратен успешно."); 
          lblInfo.setForeground(Color.red);
        }
        }
        
         if(jTextField1_addFile1.getText().length()>0 
             && jTextField2__addFile2.getText().length()>0 
  && jTextField3__addFile3.getText().length()>0){
             
             @SuppressWarnings("MismatchedReadAndWriteOfArray")
             String[] attachFiles = new String[3];
        attachFiles[0] = selectedFile;
        attachFiles[1] = selectedFile1;  
         attachFiles[2] = selectedFile2; 
        try {
            sendEmailWithAttachments(host, port, mailFrom, password, mailTo,
                subject, message, attachFiles);
           lblInfo.setText("Вашият емайл е изпратен успешно."); 
            lblInfo.setForeground(Color.GREEN);
        } catch (Exception ex) {
            lblInfo.setText("Вашият емайл не е изпратен успешно."); 
               lblInfo.setForeground(Color.red);
        }
        }
         
            if(jTextField1_addFile1.getText().length()>0 
             && jTextField2__addFile2.getText().length()>0 
  && jTextField3__addFile3.getText().length()>0
    && jTextField4__addFile4.getText().length()>0){
             
             @SuppressWarnings("MismatchedReadAndWriteOfArray")
             String[] attachFiles = new String[4];
        attachFiles[0] = selectedFile;
        attachFiles[1] = selectedFile1;  
         attachFiles[2] = selectedFile2; 
          attachFiles[3] = selectedFile3; 
        try {
            sendEmailWithAttachments(host, port, mailFrom, password, mailTo,
                subject, message, attachFiles);
            lblInfo.setText("Вашият емайл е изпратен успешно."); 
             lblInfo.setForeground(Color.GREEN);
        } catch (Exception ex) {
           lblInfo.setText("Вашият емайл не е изпратен успешно."); 
              lblInfo.setForeground(Color.red);
        }
        }
        
        
        }catch(Exception e){
    }
        //uslovie samo za suob]enie
        }else{
     
        boolean isSent = true;
        
        try {
        
        Properties properties = new Properties();
	properties.setProperty("mail.smtp.submitter", txtusername.getText());
	properties.setProperty("mail.smtp.auth", "true");
	properties.setProperty("mail.smtp.host", jTextField1_hostName.getText());    
        properties.put("mail.smtp.user", txtusername.getText()); 
        properties.put("mail.smtp.port", txtPort.getText());
        properties.put("mail.smtp.socketFactory.port", txtPort.getText());
        properties.put("mail.smtp.starttls.enable","true");
        properties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        properties.put("mail.smtp.socketFactory.fallback", "false");

        Authenticator mailAuthenticator = new SendEmail1.MailAuthenticator();
	Session mailSession = Session.getDefaultInstance(properties,mailAuthenticator);
        Message message = new MimeMessage(mailSession);

        InternetAddress fromAddress = new InternetAddress(txtusername.getText());
        InternetAddress toAddress = new InternetAddress(txtto1.getText());
        
        message.setFrom(fromAddress);
        message.setRecipient(MimeMessage.RecipientType.TO, toAddress);
      
        message.setSubject(txtsubject.getText());
        message.setText(txtcontent.getText());

        Transport.send(message);
    
        } catch (Exception e) {
              lblInfo.setText("Вашият емайл не е изпратен успешно."); 
                 lblInfo.setForeground(Color.red);
           // lblInfo.setText("ERROR:" + e.getMessage());            
            isSent = false;
        }
        
        if(isSent == true) {
            jButton1sendEmail.setEnabled(false);
            lblInfo.setText("Вашият емайл беше изпратен успешно."); 
             lblInfo.setForeground(Color.GREEN);
        } 
     
     }
 
 
       
    }//GEN-LAST:event_jButton1sendEmailActionPerformed

    private void jButton1_addFile1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1_addFile1ActionPerformed
 JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(null);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
           selectedFile = fileChooser.getSelectedFile().getPath();
           
           
        }
        //ако е добавен файл следващото поле става активно
        jTextField1_addFile1.setText(selectedFile);
        if(jTextField1_addFile1.getText().length()>0){
        jTextField2__addFile2.setEnabled(true);
                jButton2_addFile2.setEnabled(true);
        }
      
    }//GEN-LAST:event_jButton1_addFile1ActionPerformed

    private void jButton2_addFile2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2_addFile2ActionPerformed
      JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(null);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
           selectedFile1 = fileChooser.getSelectedFile().getPath();
        
        }
        
         //ако е добавен файл следващото поле става активно
        jTextField2__addFile2.setText(selectedFile1);
        if(jTextField2__addFile2.getText().length()>0){
        jTextField3__addFile3.setEnabled(true);
                jButton3_addFile3.setEnabled(true);
        }
    }//GEN-LAST:event_jButton2_addFile2ActionPerformed

    private void jButton3_addFile3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3_addFile3ActionPerformed
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(null);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
           selectedFile2 = fileChooser.getSelectedFile().getPath();
         
        }
         //ако е добавен файл следващото поле става активно
       jTextField3__addFile3.setText(selectedFile2);
        if(jTextField3__addFile3.getText().length()>0){
        jTextField4__addFile4.setEnabled(true);
                jButton4_addFile4.setEnabled(true);
        }
        
    }//GEN-LAST:event_jButton3_addFile3ActionPerformed

    private void jCheckBox1ascdasvdasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCheckBox1ascdasvdasMouseClicked
    if(jCheckBox1ascdasvdas.isSelected()){
        txtPort.setText("587");
        
 
        jTextField1_addFile1.setVisible(true);
        jTextField2__addFile2.setVisible(true);
        jTextField3__addFile3.setVisible(true);
        jTextField4__addFile4.setVisible(true);
        
        jButton1_addFile1.setVisible(true);
        jButton2_addFile2.setVisible(true);
        jButton3_addFile3.setVisible(true);
        jButton4_addFile4.setVisible(true);
        
        jTextField2__addFile2.setEnabled(false);
        jTextField3__addFile3.setEnabled(false);
        jTextField4__addFile4.setEnabled(false);
         jButton2_addFile2.setEnabled(false);
        jButton3_addFile3.setEnabled(false);
        jButton4_addFile4.setEnabled(false);
        
        
    
    }else{
        txtPort.setText("465");
        
        jTextField1_addFile1.setVisible(false);
        jTextField2__addFile2.setVisible(false);
        jTextField3__addFile3.setVisible(false);
        jTextField4__addFile4.setVisible(false);
        
        jButton1_addFile1.setVisible(false);
        jButton2_addFile2.setVisible(false);
        jButton3_addFile3.setVisible(false);
        jButton4_addFile4.setVisible(false);
    
    }
    }//GEN-LAST:event_jCheckBox1ascdasvdasMouseClicked

    private void jButton4_addFile4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4_addFile4ActionPerformed
       JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(null);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
           selectedFile3 = fileChooser.getSelectedFile().getPath();
           jTextField4__addFile4.setText(selectedFile3);
        }
    }//GEN-LAST:event_jButton4_addFile4ActionPerformed

    private void jCheckBox1ascdasvdasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ascdasvdasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox1ascdasvdasActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JButton jButton1_addFile1;
    private javax.swing.JButton jButton1sendEmail;
    public static javax.swing.JButton jButton2_addFile2;
    private javax.swing.JButton jButton3;
    public static javax.swing.JButton jButton3_addFile3;
    public static javax.swing.JButton jButton4_addFile4;
    private javax.swing.JCheckBox jCheckBox1ascdasvdas;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPasswordField jPasswordField1passsss;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTextField jTextField1_addFile1;
    public static javax.swing.JTextField jTextField1_hostName;
    public static javax.swing.JTextField jTextField2__addFile2;
    public static javax.swing.JTextField jTextField3__addFile3;
    public static javax.swing.JTextField jTextField4__addFile4;
    private javax.swing.JLabel lblInfo;
    public static javax.swing.JTextField txtPort;
    public static javax.swing.JTextArea txtcontent;
    public static javax.swing.JTextField txtsubject;
    public static javax.swing.JTextField txtto1;
    public static javax.swing.JTextField txtusername;
    // End of variables declaration//GEN-END:variables
}
